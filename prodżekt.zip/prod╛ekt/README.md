# SchowekNaWygodneKapcie
Tu składować będe wszystkie wygodne kapcie jakie znajdę. Niewygodnych nie będę tu składować.
