library(modelr)
library(kableExtra)
library(ggplot2)
library(ggthemes)
library(dplyr)
library(knitr)
library(nycflights13)
library(forcats)
library(tidyverse)

ggplot(smallpox, aes(x = Code, y = Year)) +
  geom_point()

:O

ggplot(smallpox, aes(x= years, y = cases)) + geom_line(colour = 'skyblue') + theme_tufte()

  
ggplot(heights, aes(x= income, y = education)) + geom_point(colour = 'gold') + stat_summary(fun=mean, colour="green", geom="line", aes(group = 1)) + theme_base()

colours()
heights
ggplot(heights, aes(x = education, y = income, color=sex), size= 0.5) + geom_point() + stat_summary(fun=mean, geom="line", size=2) + stat_summary(fun=median, geom="line", size=2) + theme_tufte()

ggplot(heights, aes(x = education, y = income, color=sex), size= 0.5) + geom_point() + stat_summary(fun=mean, geom="line", size=2) + stat_summary(fun=median, geom="line", size=2) + facet_wrap(~marital) + theme_tufte()
ggplot(heights, aes(x = income, y = education, color=sex), size= 0.5) + geom_point() + geom_smooth(size=0.2) + theme_tufte()
faithful
ggplot(faithful, aes(x= eruptions, y= waiting), size= 0,4) + geom_point() + theme_tufte()
ggplot(heights, aes(x= income, y= sex)) + geom_boxplot(size=0.2,alpha=0.2,outlier.size = 0.1) + theme_tufte() + theme(text = element_text(size=14))
flights
twoLast <- filter(flights, month == 1 | month == 2 )
twoLast
arrange(twoLast, dep_delay)
smallpox